﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace Graph_
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        { 
            InitializeComponent();

        }
        static int numOfVersh = 0, E = 0;
        public List<Vertex> Versh, Dop, SetCopmsub;

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void lineAngle(int n, double R, Point Cntr, Point[] p)
        {
            double angle;
            angle = 360.0 / (double)n;
            double z = 0;
            for (int i = 0; i < n + 1; i++)
            {

                p[i].X = Cntr.X - (int)(Math.Round(Math.Cos(z / 180 * Math.PI) * R));
                p[i].Y = Cntr.Y + (int)(Math.Round(Math.Sin(z / 180 * Math.PI) * R));
                z += angle;
            }
        }

        private void SortSmej(int n, List<Vertex> V)
        {
            for (int i = 0; i < n; i++)
            {
                V[i].Smej.Sort();
            }
        }
        private void Create_Versh(int n, List<Vertex> V, int CenterX, int CenterY)
        {
            int k = 1;
            double R;

            Point Cntr;
            Cntr = new Point();
            Point[] p;
            R = 40 * Math.Sqrt(n);
            Cntr.X = CenterX;
            Cntr.Y = CenterY;

            p = new Point[n + 1];
            lineAngle(n, R, Cntr, p);
            for (int i = 0; i < n; i++)
            {
                V.Add(new Vertex(p[i].X, p[i].Y, k));
                k++;
            }
        }

        private void Fin_Create_Vertex(List<Vertex> V)
        {
            StreamReader fp = new StreamReader("input.txt");
            int n = Convert.ToInt32(fp.ReadLine());

            string Str;
            Create_Versh(n, V, 250, 250);

            for (int i = 0; i < n; i++)
            {
                Str = fp.ReadLine();
                if (Str != "")
                    V[i].Smej.AddRange(Str.Split(' ').Select(x => int.Parse(x) - 1));

            }
            SortSmej(n, V);
            fp.Close();
        }

        private void Create_Line(int n, List<Vertex> V, Grid Gr, SolidColorBrush color, double fatLine)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < V[i].Smej.Count; j++)
                {
                    Line L;
                    L = new Line();

                    L.X1 = V[i].X + 10;
                    L.Y1 = V[i].Y + 10;
                    L.X2 = V[V[i].Smej[j]].X + 10;
                    L.Y2 = V[V[i].Smej[j]].Y + 10;
                    L.Stroke = color;
                    L.StrokeThickness = fatLine;
                    Gr.Children.Add(L);
                }

            }
        }

        private void PrintVersh(int n, List<Vertex> V, Grid Gr)
        {
            for (int i = 0; i < n; i++)
            {
                V[i].AddToGrid(Gr);
            }
        }


        private void InicializeDopGraph(int n, List<Vertex> V)
        {
            for (int i = 0; i < n; i++)
            {
                for (int j = 1; j < n; j++)
                {
                    if (i != j)
                    {
                        V[i].Smej.Add(j);
                    }

                }

            }

        }

        private void Create_DopGraph(int n, List<Vertex> V, List<Vertex> Dop)
        {
            InicializeDopGraph(n, Dop);
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < V[i].Smej.Count(); j++)
                {
                    for (int z = 0; z < Dop[i].Smej.Count(); z++)
                    {

                        if (V[i].Smej[j] == Dop[i].Smej[z])
                        {
                            Dop[i].Smej.Remove(Dop[i].Smej[z]);
                        }

                    }
                }
            }
        }



        private void BtnFine_Click(object sender, RoutedEventArgs e)
        {
            StreamReader fp = new StreamReader("input.txt");
            Gr1.Children.Clear();



            numOfVersh = Convert.ToInt32(fp.ReadLine());
            Versh = new List<Vertex>(numOfVersh);

            Dop = new List<Vertex>(numOfVersh);

            Fin_Create_Vertex(Versh);

            Create_Versh(numOfVersh, Dop, 250, 250);
            Create_DopGraph(numOfVersh, Versh, Dop);

            Create_Line(numOfVersh, Versh, Gr1, Brushes.Black, 1.5);

            PrintVersh(numOfVersh, Versh, Gr1);

            fp.Close();


        }


        private void Random_Smej(int n, List<Vertex> V)
        {

            int k;
            var rand = new Random();
            for (int i = 0; i < n; i++)
            {
                for (int j = i; j < n; j++)
                {
                    k = rand.Next(0, 2);

                    if (k == 1 && i != j)
                    {
                        E++;
                        V[i].Smej.Add(j);
                        V[j].Smej.Add(i);

                    }
                }
            }


        }



        private void RadioTextBox_Checked(object sender, RoutedEventArgs e)
        {
            textBox_NumberOfVersh.IsEnabled = true;
        }

        private void Rand_Click(object sender, RoutedEventArgs e)
        {
            Gr1.Children.Clear();
            Random rand = new Random();
            if (RadioTextBox.IsChecked == true)
            {
                if (textBox_NumberOfVersh.Text.Length != 0)
                {
                    int x = Convert.ToInt32(textBox_NumberOfVersh.Text);
                    if (x > 1 && x < 36)
                    {
                        Alarm.Content = "";
                        numOfVersh = x;
                    }
                    else
                    {
                        Alarm.Content = "Введено некорректное значение!!!";
                    }
                }
            }
            else
            {
                numOfVersh = rand.Next(2, 35);
            }

            Versh = new List<Vertex>(numOfVersh);
            Create_Versh(numOfVersh, Versh, 250, 250);
            Random_Smej(numOfVersh, Versh);
            SortSmej(numOfVersh, Versh);
            Dop = new List<Vertex>(numOfVersh);


            Create_Versh(numOfVersh, Dop, 250, 250);
            Create_DopGraph(numOfVersh, Versh, Dop);


            Create_Line(numOfVersh, Versh, Gr1, Brushes.Black, 1.5);
            PrintVersh(numOfVersh, Versh, Gr1);

        }

        private bool Possible(List<int> Cand, List<int> Not, List<Vertex> V)
        {
            bool key = true;
            for (int i = 0; i < Not.Count(); i++)
            {
                if (V[Not[i]].Smej == Cand)
                {
                    key = false;
                    i = Not.Count();
                }

            }
            return key;
        }

        bool Independent(List<Vertex> V)
        {
            bool k = true;
            for (int i = 0; i < V.Count(); i++)
            {
                if (V[i].Smej.Count() > 0)
                {
                    k = false;
                }
            }
            
            return k;
        }

        void extend(List<int> Cand, List<int> Not, List<int> Compsub, List<Vertex> V, List<Vertex> SetCompsub)
        {
            while (Cand.Count() > 0 && Possible(Cand, Not, V))
            {
                int v = Cand[0];
                Compsub.Add(v);
                List<int> new_not;
                List<int> new_cands;
                List<int> notSmej;
                notSmej = new List<int>();
                new_not = new List<int>();
                new_cands = new List<int>();

                for (int i = 0; i < Cand.Count(); i++)
                {
                    new_cands.Add(Cand[i]);
                }
                for (int i = 0; i < Not.Count(); i++)
                {
                    new_not.Add(Not[i]);
                }

                for (int i = 0; i < numOfVersh; i++)
                {
                    notSmej.Add(i);
                }
                for (int i = 0; i < V[v].Smej.Count(); i++)
                {
                    for (int j = 0; j < notSmej.Count(); j++)
                    {
                        if (V[v].Smej[i] == notSmej[j])
                            notSmej.Remove(notSmej[j]);
                    }
                }

                for (int i = 0; i < notSmej.Count(); i++)
                {
                    new_not.Remove(notSmej[i]);
                    new_cands.Remove(notSmej[i]);
                }



                if (new_cands.Count() == 0 && new_not.Count() == 0)
                {

                    if (Compsub.Count() > 1)
                    {

                        SetCompsub.Add(new Vertex(0, 0, SetCompsub.Count()));
                        if (SetCompsub[SetCompsub.Count() - 1].Smej.Count() == 0)
                        {
                            for (int j = 0; j < Compsub.Count(); j++)
                            {
                                SetCompsub[SetCompsub.Count() - 1].Smej.Add(Compsub[j]);
                            }
                        }
                    }
                }
                else
                {
                    extend(new_cands, new_not, Compsub, V, SetCompsub);
                }
                Compsub.Remove(v);
                Not.Add(v);
                Cand.Remove(v);

            }
        }

        public List<int> Painted_Versh = new List<int>();


        private void DefaultPaintedVersh()
        {
            for (int i = 0; i < numOfVersh; i++)
            {
                if (Versh[i].El.Stroke != Brushes.Gray && Versh[i].El.Fill != Brushes.LightPink)
                {
                    Versh[i].El.Stroke = Brushes.Gray;
                    Versh[i].El.Fill = Brushes.LightPink;
                    Versh[i].Num.Content = i + 1;
                }
            }
        }     
        private void PaintVersh(ListBox list, SolidColorBrush brushStroke, SolidColorBrush brushFill)
        {
            String str = "";
            List<int> V;
            V = new List<int>();
            for (int i = 0; i < Painted_Versh.Count(); i++)
            {
                Gr1.Children.Remove(Versh[Painted_Versh[i]].El);
                Gr1.Children.Remove(Versh[Painted_Versh[i]].Num);

                Versh[Painted_Versh[i]].El.Stroke = Brushes.Gray;
                Versh[Painted_Versh[i]].El.Fill = Brushes.LightPink;
                Versh[Painted_Versh[i]].Num.Content = (Painted_Versh[i] + 1);

                Gr1.Children.Add(Versh[Painted_Versh[i]].El);
                Gr1.Children.Add(Versh[Painted_Versh[i]].Num);
            }

            Painted_Versh.Clear();

            str = (string)list.SelectedItems[0];
            if (str != "")
            {


                V.AddRange(str.Split(' ').Select(x => int.Parse(x) - 1));
                for (int i = 0; i < V.Count(); i++)
                {
                    Painted_Versh.Add(V[i]);
                    Gr1.Children.Remove(Versh[V[i]].El);
                    Gr1.Children.Remove(Versh[V[i]].Num);

                    Versh[V[i]].El.Stroke = brushStroke;
                    Versh[V[i]].El.Fill = brushFill;
                    Versh[V[i]].Num.Content = (V[i] + 1);

                    Gr1.Children.Add(Versh[V[i]].El);
                    Gr1.Children.Add(Versh[V[i]].Num);

                }
            }
        }


        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listIndepVersh.SelectedItems.Count > 0)
            {

                PaintVersh(listIndepVersh, Brushes.Black, Brushes.Yellow);

            }


        }

        private void btnIndep_Click(object sender, RoutedEventArgs e)
        {
            DefaultPaintedVersh();
            listIndepVersh.Items.Clear();
            Painted_Versh.Clear();
            SetCopmsub = new List<Vertex>(numOfVersh);
            List<int> Cand, Not, Compsub;
            Cand = new List<int>(numOfVersh);
            String str = "";
            for (int i = 0; i < numOfVersh; i++)
                Cand.Add(i);
            Not = new List<int>(numOfVersh);
            Compsub = new List<int>(numOfVersh);
            extend(Cand, Not, Compsub, Dop, SetCopmsub);
            for (int i = 0; i < SetCopmsub.Count(); i++)
            {
                str = "";
                for (int j = 0; j < SetCopmsub[i].Smej.Count(); j++)
                {
                    str += Convert.ToString(SetCopmsub[i].Smej[j] + 1);
                    if (j < SetCopmsub[i].Smej.Count() - 1)
                        str += " ";
                }
                listIndepVersh.Items.Add(str);
            }
        }

        private void Delete(List<Vertex> V, int del)
        {


            for (int i = 0; i < V.Count(); i++)
            {
                if (i == del)
                {

                    for (int k1 = 0; k1 < V.Count(); k1++)
                    {
                        for (int k2 = 0; k2 < V[k1].Smej.Count(); k2++)
                        {
                            if (V[k1].Smej[k2] == i)
                            {
                                V[k1].Smej.Remove(i);
                            }
                        }
                    }
                    for (int k1 = 0; k1 < V.Count(); k1++)
                    {
                        for (int k2 = 0; k2 < V[k1].Smej.Count(); k2++)
                        {
                            V[k1].Smej[k2]--;
                        }
                    }
                    V.RemoveAt(i);
                }

            }
        }



        void Delete_Vershs(List<Vertex> V, List<int> Mnoj)
        {
            for (int i = 0; i < Mnoj.Count(); i++)
            {
                Delete(V, Mnoj[i]);
                for (int j = i; j < Mnoj.Count(); j++)
                {
                    Mnoj[j]--;
                }
            }

        }

        private int MaxSize(List<Vertex> V)
        {
            int size = 0;
            for (int i = 0; i < V.Count(); i++)
            {
                if (size < V[i].Smej.Count())
                {
                    size = V[i].Smej.Count();
                }
            }

            return size;
        }

        private void btnPokr_Click(object sender, RoutedEventArgs e)
        {
            DefaultPaintedVersh();
            if (Versh != null)
            {
                listMinPokr.Items.Clear();
                Painted_Versh.Clear();
                if (SetCopmsub == null)
                {
                    SetCopmsub = new List<Vertex>(numOfVersh);
                    List<int> Cand, Not, Compsub;
                    Cand = new List<int>(numOfVersh);
                    for (int i = 0; i < numOfVersh; i++)
                    {
                        Cand.Add(i);
                    }

                    Not = new List<int>(numOfVersh);
                    Compsub = new List<int>(numOfVersh);
                    extend(Cand, Not, Compsub, Dop, SetCopmsub);
                }
                List<int> MinPokr;
                MinPokr = new List<int>();
                string str = "";
                if (SetCopmsub.Count() == 0)
                {

                    for (int j = 0; j < Versh.Count(); j++)
                    {
                        MinPokr.Add(j);
                    }
                    for (int j = 0; j < Versh.Count(); j++)
                    {
                        MinPokr.Remove(j);
                        for (int j1 = 0; j1 < Versh.Count() - 1; j1++)
                        {
                            str += Convert.ToString(MinPokr[j1] + 1);
                            if (j1 < MinPokr.Count() - 1)
                                str += " ";
                        }
                        MinPokr.Add(j);
                        listMinPokr.Items.Add(str);
                        str = "";
                    }

                }
                else
                {
                    int size = MaxSize(SetCopmsub);
                    for (int i = 0; i < SetCopmsub.Count(); i++)
                    {
                        MinPokr.Clear();
                        str = "";
                        for (int j = 0; j < Versh.Count(); j++)
                        {
                            MinPokr.Add(j + 1);
                        }
                        if (SetCopmsub[i].Smej.Count() == size)
                        {
                            for (int j = 0; j < SetCopmsub[i].Smej.Count(); j++)
                            {
                                MinPokr.Remove(SetCopmsub[i].Smej[j] + 1);
                            }

                            for (int j = 0; j < MinPokr.Count(); j++)
                            {
                                str += Convert.ToString(MinPokr[j]);
                                if (j < MinPokr.Count() - 1)
                                    str += " ";
                            }

                            listMinPokr.Items.Add(str);
                        }

                    }
                }
            }

        }
        private void listMinPokr_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (listMinPokr.SelectedItems.Count > 0)
            {
                PaintVersh(listMinPokr, Brushes.Black, Brushes.Red);
            }

        }

    }

}
