﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Graph_
{
    public class Vertex
    {
        private Ellipse el;
        private Label num;
        private double x;
        private double y;
        private List<int> smej;

        public double X
        {
            get
            {
                return x;
            }
            set
            {
                x = value;
            }
        }
        public double Y
        {
            get
            {
                return y;
            }
            set
            {
                y = value;
            }
        }

        public Ellipse El
        {
            get
            {
                return el;
            }
            set
            {
                el = value;
            }
        }
        public Label Num
        {
            get
            {
                return num;
            }
            set
            {
                num = value;
            }
        }
        public List<int> Smej
        {
            get
            {
                return smej;
            }
            set
            {
                smej = value;
            }
        }
        public Vertex(double x, double y, int k)
        {

            Ellipse El;
            Label Num;
            Num = new Label();
            Num.Content = k;
            Smej = new List<int>();

            El = new Ellipse
            {
                Width = 20,
                Height = 20,
                Fill = Brushes.LightPink,
                Stroke = Brushes.Gray,
                StrokeThickness = 2,
                VerticalAlignment = VerticalAlignment.Top,
                HorizontalAlignment = HorizontalAlignment.Left
            };

            X = x - (El.Width / 2);
            Y = y - (El.Width / 2);
            El.Margin = new Thickness(X, Y, 0, 0);
            if (k < 10)
            {
                Num.Margin = new Thickness(x - (El.Width / 2.2), y - (El.Width / 1.5), 0, 0);
            }
            else
            {
                Num.Margin = new Thickness(x - (El.Width / 1.6), y - (El.Width / 1.5), 0, 0);
            }

            this.El = El;
            this.Num = Num;
        }
        public void AddToGrid(Grid Gr)
        {
            Gr.Children.Add(El);
            Gr.Children.Add(Num);
        }



    }
}
